import React from 'react';
import { Bot, Gauge, Code2, Sparkles } from 'lucide-react';
import { cn } from './ui/utils';

interface ETASAvatarProps {
  type: 'welcome' | 'calibration' | 'swdev' | 'aura';
  size?: 48 | 64;
  className?: string;
}

export const ETASAvatar: React.FC<ETASAvatarProps> = ({
  type,
  size = 48,
  className,
}) => {
  const avatarConfig = {
    welcome: {
      icon: Bot,
      color: 'bg-[#164293]',
    },
    calibration: {
      icon: Gauge,
      color: 'bg-[#039C7D]',
    },
    swdev: {
      icon: Code2,
      color: 'bg-[#89037A]',
    },
    aura: {
      icon: Sparkles,
      color: 'bg-gradient-to-br from-[#164293] to-[#89037A]',
    },
  };

  const config = avatarConfig[type];
  const Icon = config.icon;
  const iconSize = size === 64 ? 32 : 24;

  return (
    <div 
      className={cn(
        "rounded-full flex items-center justify-center flex-shrink-0",
        config.color,
        className
      )}
      style={{ width: `${size}px`, height: `${size}px` }}
    >
      <Icon className="text-white" style={{ width: `${iconSize}px`, height: `${iconSize}px` }} />
    </div>
  );
};
