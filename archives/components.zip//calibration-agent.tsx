import React, { useState } from 'react';
import { ETASHeader } from './etas-header';
import { ETASButton } from './etas-button';
import { ChatBubble } from './chat-bubble';
import { AnimationPlaceholder } from './animation-placeholder';
import { SectionContainer } from './section-container';
import { ChatDock } from './chat-dock';
import { CollapsiblePanel } from './collapsible-panel';
import { Gauge, Cpu, Database } from 'lucide-react';

interface CalibrationAgentProps {
  onNavigate: (screen: string) => void;
}

export const CalibrationAgent: React.FC<CalibrationAgentProps> = ({ onNavigate }) => {
  const [isPanelMinimized, setIsPanelMinimized] = useState(false);

  return (
    <>
      <ETASHeader title="Calibration & Data Analytics Agent" onNavigate={onNavigate} />
      <SectionContainer>
        <div className="h-full flex flex-col">
        
        <div className="flex-1 flex flex-col lg:flex-row gap-3 sm:gap-4 p-3 sm:p-4 pb-0 overflow-hidden">
          {/* Left Panel - Chat */}
          <div className="flex-1 flex flex-col min-h-0">
            <div className="bg-white rounded-xl shadow-lg p-3 pb-1.5 flex-1 flex flex-col">
              {/* Option Buttons - Collapsible */}
              <CollapsiblePanel
                isMinimized={isPanelMinimized}
                onRestore={() => setIsPanelMinimized(false)}
                className="h-full flex items-center justify-center"
                type="options"
              >
                <div className="flex flex-col gap-2 sm:gap-3">
                  <ETASButton
                    variant="primary"
                    icon={<Gauge className="w-3 h-3 sm:w-4 sm:h-4" />}
                    onClick={() => onNavigate('calibration-suite')}
                    className="w-full"
                  >
                    Initiate AI Calibration Suite
                  </ETASButton>
                  
                  <ETASButton
                    variant="primary"
                    icon={<Cpu className="w-3 h-3 sm:w-4 sm:h-4" />}
                    onClick={() => onNavigate('virtual-calibration')}
                    className="w-full"
                  >
                    Initiate a Virtual Calibration of a VECU
                  </ETASButton>
                  
                  <ETASButton
                    variant="primary"
                    icon={<Database className="w-3 h-3 sm:w-4 sm:h-4" />}
                    onClick={() => onNavigate('data-logging')}
                    className="w-full"
                  >
                    Analyze Data from Fleet Loggers
                  </ETASButton>
                </div>
              </CollapsiblePanel>
            </div>
          </div>
          
          {/* Right Panel - Animation - Collapsible */}
          <CollapsiblePanel
            isMinimized={isPanelMinimized}
            onRestore={() => setIsPanelMinimized(false)}
            className="hidden lg:flex items-start justify-center lg:w-1/3 overflow-hidden"
            type="animation"
          >
            <AnimationPlaceholder 
              label="ANIMATION_PLACEHOLDER_CALIBRATION"
              width={480}
              height={380}
              resizable={true}
              minWidth={300}
              minHeight={200}
            />
          </CollapsiblePanel>
        </div>

        {/* ChatDock - Fixed Bottom */}
        <ChatDock onChatActiveChange={setIsPanelMinimized} />
      </div>
      </SectionContainer>
    </>
  );
};
