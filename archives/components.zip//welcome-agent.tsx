import React, { useState } from 'react';
import { ETASHeader } from './etas-header';
import { ETASButton } from './etas-button';
import { ChatBubble } from './chat-bubble';
import { AnimationPlaceholder } from './animation-placeholder';
import { SectionContainer } from './section-container';
import { ChatDock } from './chat-dock';
import { CollapsiblePanel } from './collapsible-panel';
import { Globe, Gauge, Code2, Library } from 'lucide-react';

interface WelcomeAgentProps {
  onNavigate: (screen: string) => void;
}

export const WelcomeAgent: React.FC<WelcomeAgentProps> = ({ onNavigate }) => {
  const [isPanelMinimized, setIsPanelMinimized] = useState(false);

  return (
    <>
      <ETASHeader onNavigate={onNavigate} />
      <SectionContainer>
        <div className="h-full flex flex-col gap-0">
        
        <div className="flex-[0.6] flex flex-col px-2 pt-2 pb-0 overflow-hidden">
          <div className="bg-white rounded-[15px] shadow-lg p-3 flex-[0.7] flex flex-col">
            {/* Option Buttons - Collapsible */}
            <CollapsiblePanel
              isMinimized={isPanelMinimized}
              onRestore={() => setIsPanelMinimized(false)}
              className="h-full flex items-center justify-center"
              type="options"
            >
              <div className="grid grid-cols-2 gap-3 max-w-4xl mx-auto">
                <ETASButton
                  variant="primary"
                  icon={<Globe className="w-4 h-4" />}
                  onClick={() => onNavigate('external-landing')}
                >
                  View the ETAS-Azure Marketplace Landing Page
                </ETASButton>
                
                <ETASButton
                  variant="primary"
                  icon={<Gauge className="w-4 h-4" />}
                  onClick={() => onNavigate('calibration')}
                >
                  Talk to Calibration & Data Analytics Agent
                </ETASButton>
                
                <ETASButton
                  variant="primary"
                  icon={<Code2 className="w-4 h-4" />}
                  onClick={() => onNavigate('swdev')}
                  className="col-span-2"
                >
                  Talk to SW Development Agent
                </ETASButton>
              </div>
            </CollapsiblePanel>
          </div>
        </div>

        {/* ChatDock - Fixed Bottom */}
        <ChatDock onChatActiveChange={setIsPanelMinimized} />
      </div>
      </SectionContainer>
      
      {/* Component Library Icon - Bottom Right */}
      <button
        onClick={() => onNavigate('component-library')}
        className="fixed bottom-4 right-4 bg-[#164293] hover:bg-[#1a4fb3] text-white p-3 rounded-full shadow-lg transition-colors z-50"
        title="View Component Library"
      >
        <Library className="w-5 h-5" />
      </button>
    </>
  );
};
