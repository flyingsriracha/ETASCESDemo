import React from 'react';
import azureLogo from 'figma:asset/ffd53de85c2ccab1755ccff4cff38502fadfd03c.png';

interface ETASHeaderProps {
  title?: string;
  onNavigate?: (screen: string) => void;
}

export const ETASHeader: React.FC<ETASHeaderProps> = ({ 
  title = "ETAS CES Demonstrator",
  onNavigate
}) => {
  return (
    <header className="gradient-etas w-screen h-20 flex items-center justify-between px-6 relative fixed top-0 left-0 right-0 z-50">
      {/* ETAS Logo and Azure branding - Left aligned */}
      <div className="flex items-center gap-4" style={{ paddingLeft: '0px', paddingTop: '0px' }}>
        <button
          onClick={() => onNavigate?.('welcome')}
          className="focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-transparent rounded transition-opacity hover:opacity-80"
          aria-label="Go to home"
        >
          <img 
            src="https://cdn-assets-eu.frontify.com/s3/frontify-enterprise-files-eu/eyJwYXRoIjoiYm9zY2hcL2ZpbGVcL0E0RW9qdk1ZYUdFemt5RWtjSEJuLnN2ZyJ9:bosch:oNsWBD1PMkzzqq9RC33jUNMER77OJixLwD4KipfrCIw?width=320"
            alt="ETAS Logo"
            className="h-8 brightness-0 invert cursor-pointer"
            style={{
              width: 'auto',
              maxHeight: '32px',
              filter: 'brightness(0) invert(1) drop-shadow(0px 1px 4px rgba(0, 0, 0, 0.15))',
            }}
          />
        </button>
        
        {/* Vertical divider */}
        <div className="h-10 w-px bg-white/30"></div>
        
        {/* Azure branding */}
        <div className="flex items-center gap-2">
          <span className="text-white/90 text-xs">Powered by</span>
          <img 
            src={azureLogo}
            alt="Azure"
            className="h-11 brightness-0 invert"
            style={{
              width: 'auto',
              maxHeight: '45px',
              filter: 'brightness(0) invert(1)',
            }}
          />
        </div>
      </div>
      
      {/* Title - Centered */}
      <h1 className="text-white absolute left-1/2 transform -translate-x-1/2 text-xl lg:text-2xl whitespace-nowrap px-4">
        ETAS AI and Cloudification: Transforming the Automotive Ecosystem
      </h1>
      
      {/* Spacer for layout balance */}
      <div className="w-40"></div>
    </header>
  );
};
