import React from 'react';
import { cn } from './ui/utils';

interface ETASButtonProps {
  variant?: 'primary' | 'secondary' | 'ghost';
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  icon?: React.ReactNode;
}

export const ETASButton: React.FC<ETASButtonProps> = ({
  variant = 'primary',
  children,
  onClick,
  className,
  icon,
}) => {
  const baseStyles = "px-3 py-2 rounded-lg transition-all duration-200 flex items-center justify-center gap-1.5 min-h-[40px] text-center whitespace-normal leading-tight";
  
  const variants = {
    primary: "bg-[#164293] text-white hover:opacity-90 hover:shadow-lg hover:scale-[1.02]",
    secondary: "bg-[#89037A] text-white hover:opacity-90 hover:shadow-lg hover:scale-[1.02]",
    ghost: "bg-transparent border-2 border-[#164293] text-[#164293] hover:bg-[#164293] hover:text-white",
  };

  return (
    <button
      onClick={onClick}
      className={cn(baseStyles, variants[variant], className)}
    >
      {icon && <span className="flex-shrink-0">{icon}</span>}
      <span className="flex-1 min-w-0">{children}</span>
    </button>
  );
};
